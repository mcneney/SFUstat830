# STAT830 Group assignment 4 -Chap 7 #7
# Group members:
# Shufei Ge, Jinwan Kim ,Payman Nickchi ,Yueren Wang
# Jing Wang, Di Wu and Faezech Yazdi


#-------------------------------------------------------
# read in data 
y <- read.table("http://www.stat.cmu.edu/~larry/all-of-statistics/=data/fijiquakes.dat",header=TRUE)
ee <- ecdf(y$mag)
plot(ee)

#-------------------------------------------------------
# Chapter 7 #7(1) Draw 95% envelop for F  
#     Adapted from R code on author's website:
#     http://www.stat.cmu.edu/~larry/all-of-statistics/=Rprograms/edf.r
ecdf2 = function(x,CI=TRUE) {
  ox <- sort(x) # ordered x
  n <- length(x)
  Fhatn <- (1:n)/n
  plot(ox,Fhatn,type="l",col="black",lwd=3)
  rug(x,ticksize=0.025)
  if(CI) {
    alpha <- 0.05
    eps <- sqrt(log(2/alpha)/(2*n))
    upper <- pmin(Fhatn + eps,1)
    lower <- pmax(Fhatn - eps,0)
    lines(ox,upper,type="s",lwd=3,col=2,lty=2)
    lines(ox,lower,type="s",lwd=3,col=2,lty=2)
  }
  legend("topleft", c("Fhatn(x)", "95% bounds of F(x)"), fill=c("black","red"))
}
ecdf2(y$mag) 



#-------------------------------------------------------
# Chapter 7 #7(2) - Get the approximate 95% CI
#    Derive approximate 95% CI of ee(4.9)-ee(4.3) by using the result from Chapter7 #6
theta_hat=ee(4.9) - ee(4.3)
n=length(y$mag)
alpha=0.05
lower=theta_hat-qnorm(1-alpha/2)*sqrt(theta_hat*(1-theta_hat)/n)
upper=theta_hat+qnorm(1-alpha/2)*sqrt(theta_hat*(1-theta_hat)/n)
CI=c(lower,upper)
theta_hat
CI
