# STAT830 Group assignment 4 -Chap 8 #7
# Group members:
# Shufei Ge, Jinwan Kim ,Payman Nickchi ,Yueren Wang
# Jing Wang, Di Wu and Faezech Yazdi


#-------------------------------------------------------
# bootstrap Xmax estimation for a uniform distribution
# Simulate some Uniform(0,1) data:
set.seed(123)  
n = 50 
x <- runif(n=n,min=0,max=1)
summary(x)
T <- max(x)
T

# boostrap sampling function
boot = function(B,x) {
  Tboot <- vector(length=B)
  for(i in 1:B) {
    xstar <- sample(x,size=n,replace=TRUE)
    Tboot[i] <- max(xstar)
  }
  return(Tboot)
}

#-------------------------------------------------------
# Estimate T by bootstrap sampling
B = 1000
Tboot = boot(B,x)
summary(Tboot)

#histogram of Tboot
hist(Tboot,breaks=10,fre=FALSE,col="blue")
#plot density of Tboot
lines(density(Tboot),col="green",lwd=5)
#add true density of max(X1,...,Xn) to the histogram
x<-seq(min(Tboot),1,length=20) 
y<-n*x^(n-1)
lines(x, y, col="red", lwd=5)
legend("topleft", c("Histogram of Tboot", "Density of Tboot" ,"Density of T"), fill=c("blue","green", "red"))

