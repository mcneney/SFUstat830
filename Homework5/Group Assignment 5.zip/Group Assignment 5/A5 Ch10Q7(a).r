data=matrix(c(.225, .262, .217, .240, .230, .229, .235, .217,.209, .205, .196, .210, .202, .207, .224, .223, .220, .201),nrow=18 ,ncol=1)
indicator=matrix( c(rep("Twain",8),rep("Snodgrass",10)),nrow=18 ,ncol=1)

nt=8
ns=10

mean.t=mean(data[1:8,1])
mean.s=mean(data[9:18,1])
sample.var.t=var(data[1:8,1])
sample.var.s=var(data[9:18,1])

z.wald=(mean.t-mean.s)/sqrt(sample.var.t/8+sample.var.s/10)
p=2*pnorm(-abs(z.wald))
ci.low=(mean.t-mean.s)-1.96*sqrt(sample.var.t/8+sample.var.s/10)
ci.high=(mean.t-mean.s)+1.96*sqrt(sample.var.t/8+sample.var.s/10)
ci.low
ci.high