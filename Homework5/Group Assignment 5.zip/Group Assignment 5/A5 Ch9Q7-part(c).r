# Chapter9 Question7 (c)
n=200;
x1=160;
x2=148;
p1hat=x1/n; #mle estimator
p2hat=x2/n;
phihat=p1hat-p2hat;

#Bootstrap from binomial distribution (n,pihat)
boot = function(B,n,p) {
  Tboot <- vector(length=B)
  for(i in 1:B) {
    xstar <- rbinom(n=1, size=n, prob=p)
    Tboot[i] <- xstar/n
  }
  return(Tboot)
}

B=10000;
p1star=boot(B,n,p1hat)
p2star=boot(B,n,p2hat)
phistar=p1star-p2star
#Estimated standard error
seboot=sqrt(sum((phistar-phihat)^2)/B)
seboot
#Normal 90% CI
c(phihat-seboot*qnorm(0.950),phihat+seboot*qnorm(0.950))
