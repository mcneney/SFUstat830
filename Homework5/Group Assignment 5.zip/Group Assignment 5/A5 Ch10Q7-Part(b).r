#Homework5 Chapter10 Q7
data=c(.225, .262, .217, .240, .230, .229, .235, .217,.209, .205, .196, .210, .202, .207, .224, .223, .220, .201)
m=8 
n=10
N=m+n
tobs=abs(mean(data[1:m])-mean(data[(m+1):N]))
B=10000;
I=0; #count the number of tpermute>tobs

permutationTest=function(data,B){
  tpermute<-vector(length=B)
  for (i in 1:B){
    permuteData<-sample(data,length(data),replace=FALSE)
    tpermute[i]<-abs(mean(permuteData[1:m])-mean(permuteData[(m+1):N]))
  }
  return(tpermute)
}

tstar=permutationTest(data,B)
tdifference=tstar-tobs
pvalue=length(which(sign(tdifference)==1))/B
pvalue
